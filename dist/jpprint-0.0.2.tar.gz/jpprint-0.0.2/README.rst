JPPrint
=======================

Json Pretty Print

----

Format and print two dictionaries or json strings side by side
to give a quick overview of differences.

Use quick and dirty debugging.
